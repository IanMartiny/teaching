#! /usr/bin/env python

#Ian Solution

def scoreName(name):
    """
    scoreName(string) -- returns int value.

    This will score a given string, by adding the value of each character in
    the string. A = 1, B = 2, C = 3,...

    This will be done by looking up the ascii value of a characters and
    subtracting 64 to get the correct values.
    """
    l = [ord(x)-64 for x in name]
    return sum(l)

f = open("names.txt")
names = f.read().split(",")
names = [x.replace("\"","") for x in names]
names = sorted(names)
scores = [0]*len(names)

for i in range(len(names)):
    scores[i] = scoreName(names[i]) * (i+1)

print(sum(scores))
