#! /usr/bin/env python

def main():
    # this requires no programming whatsoever.
    # Simply write all of the numbers 1...20 in prime factorization:
    # 2  = 2
    # 3  = 3
    # 4  = 2^2
    # 5  = 5
    # 6  = 2*3
    # 7  = 7
    # 8  = 2^3
    # 9  = 3^2
    # 10 = 2*5
    # 11 = 11
    # 12 = 2^2*3
    # 13 = 13
    # 14 = 2*7
    # 15 = 3*5
    # 16 = 2^4
    # 17 = 17
    # 18 = 2*3^2
    # 19 = 19
    # 20 = 2^2*5

    # Now simply look for the highest multiple of each prime, and multiply those together:

    ans = (2**4)*(3**2)*5*7*11*13*17*19

    print("Smallest number divisible by [1,20] is: " + str(ans))




if __name__ == "__main__":
    main()
