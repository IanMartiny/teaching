#include <iostream>

#define STARTVAL 1000000
// Answer is 837799
using namespace std;

long Collatz(long n){
    long val;
    if (n % 2 == 0)
        val = n/2;
    else
        val = 3*n +1;

    return val;
}

int main(void){
    long max = 0;
    long val = 0;
    for (long i = 1; i <= STARTVAL; i++)
    {
        long num = i;
        long count = 0;
        while (num > 1){
            num = Collatz(num);
            count++;
        }
        if (count > max){
            max = count;
            val = i;
        }
    }

    cout<<"Longest chain comes from " << val << " with length " << max<<endl;

    return 0;

}


