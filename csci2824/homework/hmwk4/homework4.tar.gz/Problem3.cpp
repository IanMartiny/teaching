#include <iostream>

using namespace std;

//answer is 461372

#define MAXVAL 4000000
#define MAXINDEX 100

int f[MAXINDEX] = {0,1,1};

long fib(long n)
{
    if (f[n] != 0)
        return f[n];

    long val = fib(n-1) + fib(n-2);

    f[n] = val;

    return val;
}

int main(void)
{
    long val = 1;
    unsigned long long num = 0;
    unsigned long long sum = 0;

    while(num <= MAXVAL)
    {
        num = fib(val);
        if (num % 2 == 0)
            sum += num;

        val++;
    }

    cout<<"sum is: "<<sum<<endl;

    return 0;
}

