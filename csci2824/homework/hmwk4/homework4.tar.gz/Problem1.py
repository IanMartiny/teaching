#! /usr/bin/env python

# answer is 9831892672

def main():
    f = open("nums","r")
    nums = f.readlines()
    nums = [int(i) for i in nums if i[0] != "\n"]
    l = sum(nums)
    print("Last 10 digits are: " + str(l)[-10:])
    
if __name__ == "__main__":
    main()
